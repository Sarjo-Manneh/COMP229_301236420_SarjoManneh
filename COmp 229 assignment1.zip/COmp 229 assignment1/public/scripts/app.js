//IFEE -- Immediately invoked function expression
(function(){

  function start()
  {
    console.log("App Started...")
  }
   window.addEventListener("Load", start);
})();